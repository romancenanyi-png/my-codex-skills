---
name: find-skills
description: Helps users discover and install agent skills when they ask questions like "how do I do X", "find a skill for X", "is there a skill that can...", or express interest in extending capabilities. This skill should be used when the user is looking for functionality that might exist as an installable skill.
metadata:
  source_status: "source-exact-public"
  source_url: "https://github.com/vercel-labs/skills/blob/main/skills/find-skills/SKILL.md"
---

# Find Skills

This skill helps you discover and install skills from the open agent skills ecosystem.

## When to Use This Skill

Use this skill when the user:

- Asks "how do I do X" where X might be a common task with an existing skill
- Says "find a skill for X" or "is there a skill for X"
- Asks "can you do X" where X is a specialized capability
- Expresses interest in extending agent capabilities
- Wants to search for tools, templates, or workflows
- Mentions they wish they had help with a specific domain (design, testing, deployment, etc.)

## What is the Skills CLI?

The Skills CLI (`npx skills`) is the package manager for the open agent skills ecosystem. Skills are modular packages that extend agent capabilities with specialized knowledge, workflows, and tools.

**Key commands:**

- `npx skills find [query]` - Search for skills interactively or by keyword
- `npx skills add <package>` - Install a skill from GitHub or other sources
- `npx skills check` - Check for skill updates
- `npx skills update` - Update all installed skills

**Browse skills at:** https://skills.sh/

## How to Help Users Find Skills

### Step 1: Understand What They Need

When a user asks for help with something, identify:

1. The domain, such as React, testing, design, deployment.
2. The specific task, such as writing tests, creating animations, or reviewing PRs.
3. Whether this is a common enough task that a skill likely exists.

### Step 2: Check the Leaderboard First

Before running a CLI search, check the skills leaderboard to see if a well-known skill already exists for the domain. The leaderboard ranks skills by total installs, surfacing popular and battle-tested options.

### Step 3: Search for Skills

```bash
npx skills find [query]
```

Examples:

- User asks "how do I make my React app faster?" → `npx skills find react performance`
- User asks "can you help me with PR reviews?" → `npx skills find pr review`
- User asks "I need to create a changelog" → `npx skills find changelog`

### Step 4: Verify Quality Before Recommending

Do not recommend a skill based solely on search results. Always verify:

1. **Install count** — Prefer skills with 1K+ installs. Be cautious with anything under 100.
2. **Source reputation** — Official sources are more trustworthy than unknown authors.
3. **GitHub stars** — Check the source repository. A skill from a repo with very few stars should be treated with skepticism.

### Step 5: Present Options to the User

When you find relevant skills, present them with:

1. Skill name and what it does.
2. Install count and source.
3. Install command.
4. Link to learn more.

### Step 6: Offer to Install

```bash
npx skills add <owner/repo@skill> -g -y
```

The `-g` flag installs globally and `-y` skips confirmation prompts.

## Common Skill Categories

| Category | Example Queries |
|---|---|
| Web Development | react, nextjs, typescript, css, tailwind |
| Testing | testing, jest, playwright, e2e |
| DevOps | deploy, docker, kubernetes, ci-cd |
| Documentation | docs, readme, changelog, api-docs |
| Code Quality | review, lint, refactor, best-practices |
| Design | ui, ux, design-system, accessibility |
| Productivity | workflow, automation, git |

## Tips for Effective Searches

1. Use specific keywords.
2. Try alternative terms.
3. Check popular sources.

## When No Skills Are Found

If no relevant skills exist:

1. Acknowledge that no existing skill was found.
2. Offer to help with the task directly using general capabilities.
3. Suggest the user could create their own skill with `npx skills init`.
